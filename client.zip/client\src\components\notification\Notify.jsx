import React from 'react'
import {ToastContainer} from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
export const Notify = () => {
  return (
    <div>
        <ToastContainer position='top-right'/>
    </div>
  )
}
